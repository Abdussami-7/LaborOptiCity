package com.example.laboropticity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class WorkerListAdapter extends BaseAdapter {

    Context context;
    ArrayList<String> nameList;
    ArrayList<String> locationsList;
    LayoutInflater inflater;
    public WorkerListAdapter(Context ctx, ArrayList<String> wNames, ArrayList<String> wLocations){
        this.context = ctx;
        this.nameList = wNames;
        this.locationsList = wLocations;
        inflater = LayoutInflater.from(ctx);
    }
    @Override
    public int getCount() {
        return nameList.toArray().length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.workers_list_item, null);
        TextView tName = (TextView) view.findViewById(R.id.wNames);
        TextView tSkill = (TextView) view.findViewById(R.id.wSkills);
        tName.setText(nameList.get(i));
        tSkill.setText(locationsList.get(i));
        return view;
    }
}
